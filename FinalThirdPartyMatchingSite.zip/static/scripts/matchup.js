window.addEventListener("DOMContentLoaded", function() {
    let btns = document.getElementsByClassName("matchupbtn");
    btns.addEventListener("click", closeWindow);
});

function closeWindow(){
   
}
